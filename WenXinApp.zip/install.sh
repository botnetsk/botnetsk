#!/bin/bash
# 问心无愧 - Linux/Mac 一键安装+启动
set -e
echo "=========================================="
echo "  问心无愧 - 安装向导"
echo "=========================================="
echo ""

OS=$(uname -s)
echo "📌 检测到系统: $OS"

if ! command -v python3 &>/dev/null; then
    echo "❌ 未找到 python3, 请先安装 Python 3.10+"
    exit 1
fi
echo "✅ Python: $(python3 --version 2>&1)"

echo ""
echo "📦 安装 Python 依赖..."
python3 -m pip install --quiet --upgrade pip 2>&1 | tail -1 || true
python3 -m pip install kivy pycryptodome 2>&1 | tail -3
echo "✅ 依赖安装完成"

cd "$(dirname "$0")"

if [ ! -f "assets/proxies.txt" ] || [ ! -s "assets/proxies.txt" ]; then
    echo "⚠️  代理池文件为空, 请编辑 assets/proxies.txt 填入代理"
else
    COUNT=$(grep -c -v "^#" assets/proxies.txt 2>/dev/null | head -1 || echo 0)
    echo "✅ 代理池: $COUNT 条"
fi

echo ""
echo "=========================================="
echo "  🚀 启动中..."
echo "=========================================="
echo ""
python3 run.py
