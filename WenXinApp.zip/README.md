# 问心无愧 · 手机软件 v1.0
=================================

六接口身份证二要素核验工具 —— 手机 App 版

## 功能特性

- ✅ 接口① 政务核验（走代理池）
- ✅ 接口② 51zidan
- ✅ 接口③ i66wan
- ✅ 接口④ 天津政务
- ✅ 接口⑤ 赣服通 gov
- ✅ 接口⑥ 中意财险（**直连 + 自动预热 Session**）
- ✅ 代理池随机轮换 + 自动黑名单
- ✅ Session 过期自动恢复
- ✅ Kivy 触屏 UI（手机/电脑通用）
- ✅ 一键复制结果到剪贴板
- ✅ 离线 IP 地理位置查询
- ✅ Buildozer 编译 APK

## 快速开始

### 电脑直接跑

```bash
pip install kivy pycryptodome
python run.py
```

### 手机运行（Android · Termux）

```bash
pkg update && pkg upgrade -y
pkg install -y python openssl git
pip install kivy pycryptodome
cd WenXinApp
python run.py
```

### 编译成 APK（进阶）

需要: Ubuntu 22.04 + JDK 11 + Android SDK/NDK

```bash
sudo apt install -y git zip unzip openjdk-11-jdk
pip install buildozer Cython

export ANDROID_SDK_ROOT=/path/to/sdk
export ANDROID_NDK_ROOT=/path/to/ndk

bash build_android.sh
# 产物: bin/wenxinwukui-1.0-debug.apk
```

## 目录结构

```
WenXinApp/
├── README.md              ← 本文件
├── 使用说明.txt           ← 中文使用指南
├── run.py                 ← 一键启动（自动判断桌面/命令行）
├── buildozer.spec         ← Android 编译配置
├── install.sh             ← Linux/Mac 安装脚本
├── install.bat            ← Windows 安装脚本
├── build_android.sh       ← Android APK 编译脚本
├── src/
│   ├── main.py           ← Kivy 触屏 UI 主程序
│   ├── core.py           ← 核验核心（封装原版逻辑）
│   └── version.py        ← 版本信息
└── assets/
    ├── proxes.txt        ← 代理池（765条预置）
    └── README.txt         ← 代理池说明
```

## 使用流程

1. 启动程序 → 自动加载代理池
2. 输入**姓名**
3. 输入**身份证号码**（18位，模糊位用 x 代替）
4. 选择**接口**（单选/并发/自选）
5. 点 **🔍 开始核验**
6. 等待结果 → 点 **📋 复制结果**

## 接口⑥预热机制

> 核心创新：用接口①的"写Session"能力，给接口⑥的"直连核验"铺路

- 首次核验前，自动用**真实姓名+身份证**跑一次接口①
- 接口①走代理池（和平时完全一致）
- 服务端写好 Session 后，接口⑥直接直连核验
- Session 过期时自动重新预热
- 速度和纯直连一样快

## 注意事项

- ⚠️ 仅供合法合规的身份核验场景使用
- ⚠️ 首次运行会请求"网络/存储"权限，务必允许
- ⚠️ 代理池建议 200+ 条，越多越稳
- ⚠️ 接口⑥首次预热约 0.5~3 秒，属正常

## 技术栈

| 组件 | 技术 |
|---|---|
| UI 框架 | Kivy 2.x |
| 语言 | Python 3.10+ |
| 加密 | AES-ECB/CBC, RSA, MD5 |
| 网络 | urllib（代理池） |
| 编译 | Buildozer → APK |
| 主题 | GitHub Dark 风格 |

祝使用愉快 🚀
