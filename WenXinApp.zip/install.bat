@echo off
REM 问心无愧 - Windows 一键启动
chcp 65001 >nul 2>&1
echo ==========================================
echo   问心无愧 - Windows 启动向导
echo ==========================================
echo.

where python3 >nul 2>&1
if %errorlevel% neq 0 (
    where python >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] 未找到 Python, 请先安装 Python 3.10+
        echo          下载: https://www.python.org/downloads/
        pause
        exit /b 1
    )
    set PY=python
) else (
    set PY=python3
)

%PY% --version
echo.
echo [1/2] 安装依赖...
%PY% -m pip install kivy pycryptodome 2>&1 | findstr /V "WARNING"
echo ✅ 依赖安装完成
echo.
echo [2/2] 启动应用...
echo.
%PY% run.py
pause
