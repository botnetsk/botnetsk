#!/bin/bash
# 问心无愧 - Android APK 编译脚本
set -e

echo "=========================================="
echo "  问心无愧 - Android APK 编译"
echo "=========================================="
echo ""

echo "[1/5] 检查编译环境..."
if ! command -v java &>/dev/null; then
    echo "❌ 未安装 JDK, 请先: sudo apt install openjdk-11-jdk"
    exit 1
fi
echo "  ✅ JDK: $(java -version 2>&1 | head -1)"

if ! command -v buildozer &>/dev/null; then
    echo "  ⚠️  安装 buildozer..."
    pip install buildozer Cython 2>&1 | tail -3
fi
echo "  ✅ Buildozer: $(buildozer --version 2>&1 | head -1)"

echo ""
echo "[2/5] 检查 Android SDK..."
if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
    echo "❌ 未设置 ANDROID_SDK_ROOT"
    echo "   请先安装 Android SDK, 然后:"
    echo "   export ANDROID_SDK_ROOT=/path/to/sdk"
    echo "   export ANDROID_NDK_ROOT=/path/to/ndk"
    exit 1
fi
SDK_DIR="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
echo "  ✅ SDK: $SDK_DIR"

echo ""
echo "[3/5] 清理旧构建..."
rm -rf .buildozer bin/
echo "  ✅ 已清理"

echo ""
echo "[4/5] 编译中 (首次约 10-30 分钟)..."
echo "  这会自动下载 Python-for-Android, 请耐心等待..."
buildozer android debug 2>&1 | tee build.log | tail -20

echo ""
echo "[5/5] 检查产物..."
APK=$(find bin -name "*.apk" 2>/dev/null | head -1)
if [ -n "$APK" ]; then
    SIZE=$(du -h "$APK" | cut -f1)
    echo ""
    echo "  🎉 编译成功!"
    echo "  📦 APK: $APK ($SIZE)"
    echo ""
    echo "  安装到手机:"
    echo "    adb install -r \"$APK\""
else
    echo "  ❌ 未找到 APK, 查看 build.log 末尾:"
    tail -30 build.log
    exit 1
fi
