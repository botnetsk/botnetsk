# -*- coding: utf-8 -*-
"""
version.py —— 问心无愧 App 版本信息
"""
__version__ = "1.0.0"
__build__ = "20260801"
__codename__ = "问心无愧·手机版"
__author__ = "BOTNETSK"
__description__ = "六接口身份证二要素核验工具（含接口⑥中意财险预热直连）"
