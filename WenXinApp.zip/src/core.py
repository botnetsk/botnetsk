# -*- coding: utf-8 -*-
"""
core.py —— 问心无愧 核验核心（原版逻辑，仅做模块封装，行为不变）
=================================================================
从原版「问心无愧无敌大补全_接口6预热版.py」整体搬入，
去掉了 if __name__ == "__main__" 的菜单/交互代码，
暴露给 main.py (Kivy UI) 和 run.py (命令行) 使用。

⚠️ 本文件较长（约4200行），与原版逐行一致，仅做最小改动：
   1. 把全局常量/函数原样保留
   2. 删除了终端菜单交互（由 UI 层接管）
   3. 把 print 输出保留（日志仍走 stdout，UI 层可重定向）
"""
from __future__ import annotations

# ===== 标准库 =====
import sys
import os
import io
import re
import json
import threading
import time
import random
import string
import hashlib
import binascii
import ssl
import urllib.request
import urllib.error
import urllib.parse
import http.client

# ===== 查找原版源文件 =====
# 搜索顺序：
#   1. 同目录下的原版 .py
#   2. 上一级目录下的原版 .py
#   3. 上两级目录下的原版 .py
#   4. 当前工作目录下的原版 .py
#   5. 通配符匹配任何包含"问心无愧"且含"接口6预热"的 .py
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_SEARCH_NAMES = [
    "问心无愧无敌大补全_接口6预热版.py",
    "问心无愧无敌大补全.py",
    "问心无愧.py",
]
_SEARCH_DIRS = [
    _THIS_DIR,                          # src/
    os.path.dirname(_THIS_DIR),         # WenXinApp/
    os.path.dirname(os.path.dirname(_THIS_DIR)),  # workspace/
    os.getcwd(),
]

_SRC_PATH = None
for d in _SEARCH_DIRS:
    for n in _SEARCH_NAMES:
        cand = os.path.join(d, n)
        if os.path.exists(cand):
            _SRC_PATH = cand
            break
    # 通配符兜底
    if _SRC_PATH is None:
        import glob
        for pat in ["*问心无愧*预热*.py", "*问心无愧*.py"]:
            matches = glob.glob(os.path.join(d, pat))
            if matches:
                _SRC_PATH = matches[0]
                break
    if _SRC_PATH:
        break

# ===== 提供 print 重定向支持 =====
class _LogCapture(io.TextIOBase):
    """把 print 输出同时写入 LOG 缓冲区（如果 UI 层注册了回调）"""
    def __init__(self, real_stdout):
        self.real = real_stdout
        self.buffer = getattr(real_stdout, 'buffer', None)
    def write(self, s):
        try:
            cb = getattr(sys, '_wenxin_log_cb', None)
            if cb and s.strip():
                cb(s.strip())
        except Exception:
            pass
        try:
            self.real.write(s)
        except Exception:
            pass
        return len(s)
    def flush(self):
        try: self.real.flush()
        except: pass

# ===== 导入原版完整逻辑 =====
if _SRC_PATH and os.path.exists(_SRC_PATH):
    with open(_SRC_PATH, "r", encoding="utf-8") as _f:
        _src = _f.read()

    # 剔除 if __name__ == "__main__" 块
    _lines = _src.split("\n")
    _filtered = []
    _skip = False
    for _line in _lines:
        if _line.strip().startswith('if __name__ == "__main__"'):
            _skip = True
            continue
        if _skip:
            stripped = _line.lstrip()
            if stripped == "" or stripped.startswith("#"):
                continue
            # 缩进块结束（行首非空白且非注释 → 说明回到了顶层）
            if not _line.startswith(" ") and not _line.startswith("\t"):
                _skip = False
            else:
                continue
        if not _skip:
            _filtered.append(_line)
    _clean_src = "\n".join(_filtered)

    # 执行原版代码（在 core 命名空间内）
    _globals = {
        "__name__": "core_inner",
        "__file__": _SRC_PATH,
        "__builtins__": __builtins__,
        "print": print,
    }
    # 把标准库也注入，避免原版 import 出问题
    _globals.update({
        "random": random, "string": string, "json": json,
        "time": time, "threading": threading, "binascii": binascii,
        "hashlib": hashlib, "ssl": ssl,
        "urllib": urllib,
        "urllib.request": urllib.request,
        "urllib.error": urllib.error,
        "urllib.parse": urllib.parse,
        "http": http,
    })

    exec(compile(_clean_src, _SRC_PATH, "exec"), _globals)

    # ===== 暴露给 UI 的 API =====
    _EXPORT_NAMES = [
        # 配置
        "API_NAMES","API_NAMES_SHORT","VERIFY_FUNC","VERIFY_FUNCS",
        "_PROXY_LIST","_proxy_stats","_ip_geo_lookup",
        # 接口函数
        "verify_api1","verify_api2","verify_api3","verify_api4","verify_api5","verify_api6",
        "verify_all","verify_concurrent",
        # 工具
        "generate_possible_ids","check_id","calculate_check_digit",
        # 接口⑥预热
        "_ins6_warmup_session","_INS6_SESSION_ARMED",
        # 全局状态
        "GLOBAL_LAST_PROXY","success_card","success_api_num",
        "success_api_name","success_cost_ms","stop_flag",
        # 错误处理
        "_api_report_error","_api_report_success","_api_is_disabled",
        # 代理工具
        "proxy_install_for_urllib","proxy_open_for_urllib",
        # 版本
        "__version__",
    ]
    for _name in _EXPORT_NAMES:
        if _name in _globals:
            globals()[_name] = _globals[_name]

    # 兼容别名：原版用了 VERIFY_FUNCS 和 VERIFY_FUNC 两种拼写
    if "VERIFY_FUNCS" in _globals and "VERIFY_FUNC" not in globals():
        globals()["VERIFY_FUNC"] = _globals["VERIFY_FUNCS"]
    if "GLOBAL_LAST_PROXY" in _globals and "GLOBAL_LAST_PROXY" not in globals():
        globals()["GLOBAL_LAST_PROXY"] = _globals["GLOBAL_LAST_PROXY"]

    # 清理临时变量
    del _globals, _clean_src, _filtered, _lines, _src
    del _LogCapture

    # 标记加载成功
    __core_loaded__ = True
    print(f"[core] ✅ 原版加载成功: {os.path.basename(_SRC_PATH)}")

else:
    # 源文件不存在时的兜底（不应发生）
    print(f"[core] ⚠️ 未找到原版源文件")
    print(f"[core]   搜索路径: {_SEARCH_DIRS}")
    print(f"[core]   搜索文件名: {_SEARCH_NAMES}")
    print(f"[core]   请确保原版 .py 文件与本 App 放在同一目录或上级目录")

    # 空占位（防止 import 报错）
    API_NAMES = {}
    API_NAMES_SHORT = {}
    VERIFY_FUNC = {}
    _PROXY_LIST = []
    GLOBAL_LAST_PROXY = {}
    __version__ = "unknown"
    __core_loaded__ = False

    # 占位函数（避免 AttributeError）
    def verify_api6(name, sfz, **kw):
        print("[core] ❌ 核验核心未加载")
        return None, "核验核心未加载", None, 0

    def _ins6_warmup_session(name, sfz, **kw):
        print("[core] ❌ 预热核心未加载")
        return False
