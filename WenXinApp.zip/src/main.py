# -*- coding: utf-8 -*-
"""
问心无愧 · 手机版 主程序
=================================
- 基于 Kivy 触屏 UI
- 后端核验逻辑完全复用原版（六接口 + 代理池 + 接口⑥预热机制）
- 仅供合法合规的身份核验场景使用
"""

import sys
import os
import json
import threading
import time
import traceback

# ===== Kivy imports =====
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.clock import Clock, mainthread
from kivy.utils import get_color_from_hex
from kivy.metrics import dp
from kivy.logger import Logger

# ===== 导入核验核心（原版逻辑，一字不改） =====
from core import (
    # 配置
    API_NAMES, API_NAMES_SHORT, VERIFY_FUNC,
    _PROXY_LIST, _proxy_stats, _ip_geo_lookup,
    # 接口函数
    verify_api1, verify_api2, verify_api3, verify_api4, verify_api5, verify_api6,
    # 工具
    generate_possible_ids, check_id,
    # 接口⑥预热
    _ins6_warmup_session, _INS6_SESSION_ARMED,
    # 全局状态
    GLOBAL_LAST_PROXY,
    # 版本
    __version__ as CORE_VERSION,
)

# ============================================================
# 颜色主题
# ============================================================
COLORS = {
    "bg":        "#0D1117",
    "panel":     "#161B22",
    "accent":    "#58A6FF",
    "accent2":   "#3FB950",
    "accent3":   "#F0883E",
    "warn":      "#F85149",
    "text":      "#C9D1D9",
    "text_dim":  "#8B949E",
    "border":    "#30363D",
    "input_bg":  "#0D1117",
    "green":     "#3FB950",
    "red":       "#F85149",
    "yellow":    "#D29922",
    "cyan":      "#39D2C0",
    "magenta":   "#BC8CFF",
}

def hex_to_rgba(hex_color, alpha=1.0):
    """#RRGGBB → (r,g,b,a) 0-1"""
    h = hex_color.lstrip("#")
    if len(h) != 6:
        return (1, 1, 1, alpha)
    r, g, b = int(h[0:2], 16)/255, int(h[2:4], 16)/255, int(h[4:6], 16)/255
    return (r, g, b, alpha)


# ============================================================
# 日志缓冲区（线程安全，供 UI 轮询显示）
# ============================================================
class LogBuffer:
    def __init__(self, max_lines=500):
        self.max_lines = max_lines
        self.lines = []
        self.lock = threading.Lock()

    def add(self, text, color="text"):
        with self.lock:
            # 去掉 ANSI 颜色码（终端用的）
            clean = text
            for c in ["\x1b[91m","\x1b[92m","\x1b[93m","\x1b[94m",
                      "\x1b[95m","\x1b[96m","\x1b[97m","\x1b[1m","\x1b[0m"]:
                clean = clean.replace(c, "")
            clean = clean.strip()
            if clean:
                self.lines.append((clean, color))
                if len(self.lines) > self.max_lines:
                    self.lines = self.lines[-self.max_lines:]

    def get_all(self):
        with self.lock:
            return list(self.lines)

    def clear(self):
        with self.lock:
            self.lines.clear()


LOG = LogBuffer()


# ============================================================
# 核验引擎（后台线程）
# ============================================================
class VerifyEngine:
    """封装单次 / 批量核验逻辑，在后台线程运行"""

    def __init__(self, app_ref):
        self.app = app_ref
        self.stop_flag = False
        self.running = False

    # ---------- 日志 ----------
    def log(self, msg, color="text"):
        LOG.add(msg, color)
        # 通知 UI 刷新
        Clock.schedule_once(lambda dt: self.app.refresh_log(), 0)

    # ---------- 单次核验 ----------
    def single_verify(self, name, sfz, api_choice):
        """单次核验：选一个接口 或 全部并发"""
        self.running = True
        self.stop_flag = False
        self.log(f"{'='*50}", "text_dim")
        self.log(f"▶ 开始单次核验 姓名={name} 身份证={sfz}", "cyan")
        self.log(f"  接口选择: {api_choice}", "text_dim")

        try:
            # 接口⑥预热
            if "⑥" in api_choice or "全部" in api_choice or "并发" in api_choice:
                self.log("🔥 接口⑥预热阶段（用真实身份证预填Session）...", "cyan")
                try:
                    _ins6_warmup_session(name, sfz, force=True)
                except Exception as e:
                    self.log(f"  ⚠️ 预热异常: {e}", "yellow")

            # 并发模式
            if "并发" in api_choice:
                from core import verify_concurrent
                self.log("▶ 并发模式：六接口同时验...", "cyan")
                matched, msg, details, winner, cost = verify_concurrent(name, sfz)
                self._show_result(name, sfz, matched, msg, details, winner, cost)
                return

            # 自选接口
            api_map = {"①":1,"②":2,"③":3,"④":4,"⑤":5,"⑥":6}
            chosen = [v for k, v in api_map.items() if k in api_choice]
            if not chosen:
                chosen = list(range(1, 7))

            details = {}
            for n in chosen:
                if self.stop_flag:
                    break
                func = VERIFY_FUNC.get(n)
                if not func:
                    continue
                aname = API_NAMES.get(n, f"接口{n}")
                self.log(f"  ▶ {aname}...", "text")
                try:
                    m, msg, data, cost = func(name, sfz)
                    details[f'api{n}'] = {'matched': m, 'msg': msg, 'cost': cost}
                    if m is True:
                        self.log(f"  ✅ {aname} 匹配! [{msg}]", "green")
                    elif m is False:
                        self.log(f"  ❌ {aname} 不匹配 [{msg}]", "red")
                    else:
                        self.log(f"  ⚠️ {aname} 异常 [{msg}]", "yellow")
                except Exception as e:
                    details[f'api{n}'] = {'matched': None, 'msg': str(e), 'cost': 0}
                    self.log(f"  ❌ {aname} 异常: {e}", "red")

            # 汇总
            matched = any(d.get('matched') is True for d in details.values())
            winner = None
            for k, d in details.items():
                if d.get('matched') is True:
                    winner = int(k.replace('api',''))
                    break
            self._show_result(name, sfz, matched, "", details, winner, 0)

        except Exception as e:
            self.log(f"❌ 核验异常: {e}", "red")
            self.log(traceback.format_exc(), "red")
        finally:
            self.running = False
            Clock.schedule_once(lambda dt: self.app.on_verify_finished(), 0)

    def _show_result(self, name, sfz, matched, msg, details, winner, cost):
        """在日志中打印结果摘要"""
        self.log(f"{'='*50}", "text_dim")
        if matched:
            self.log(f"🎉 核验成功！", "green")
            self.log(f"  姓名: {name}", "text")
            self.log(f"  身份证: {sfz}", "yellow")
            if winner:
                self.log(f"  命中接口: {API_NAMES.get(winner, winner)}", "green")
            # 代理信息
            proxy = GLOBAL_LAST_PROXY.get('proxy', '')
            if proxy:
                ip = proxy.split(':')[0]
                geo = _ip_geo_lookup(ip)
                self.log(f"  核验IP: {proxy}", "cyan")
                self.log(f"  IP位置: {geo}", "cyan")
            # 保存
            try:
                save_dir = os.path.expanduser("~/Documents")
                os.makedirs(save_dir, exist_ok=True)
                sp = os.path.join(save_dir, "验证成功身份证.txt")
                with open(sp, 'w', encoding='utf-8') as f:
                    f.write(sfz + "\n")
                self.log(f"  已保存: {sp}", "text_dim")
            except Exception:
                pass
        else:
            self.log(f"❌ 不匹配 或 未找到", "red")
        # 原始返回
        for k, d in details.items():
            m = d.get('matched')
            ms = d.get('msg', '')
            tag = "✅" if m is True else ("❌" if m is False else "⚠️")
            # 截断过长
            if len(ms) > 80:
                ms = ms[:80] + "..."
            self.log(f"  {k}: {tag} {ms}", "text_dim")
        self.log(f"{'='*50}", "text_dim")

    # ---------- 批量核验 ----------
    def batch_verify(self, name, sfz_list, api_choice, threads=8):
        """批量核验（从文件加载的列表）"""
        self.running = True
        self.stop_flag = False
        total = len(sfz_list)
        self.log(f"{'='*50}", "text_dim")
        self.log(f"▶ 批量核验 姓名={name} 共 {total} 条 {threads}线程", "cyan")

        # 预热
        if total > 0 and ("⑥" in api_choice or "全部" in api_choice):
            self.log("🔥 接口⑥预热...", "cyan")
            try:
                _ins6_warmup_session(name, sfz_list[0], force=True)
            except Exception as e:
                self.log(f"  ⚠️ 预热异常: {e}", "yellow")

        from core import verify_all, verify_concurrent
        checked = 0
        found = False
        for i, sfz in enumerate(sfz_list):
            if self.stop_flag:
                self.log("⏹️ 用户停止", "yellow")
                break
            checked += 1
            if "并发" in api_choice:
                matched, msg, details, winner, cost = verify_concurrent(name, sfz)
            else:
                matched, msg, details, cost = verify_all(name, sfz)
            if matched:
                self.log(f"✅ 第{i+1}/{total} 命中! {sfz}", "green")
                self._show_result(name, sfz, True, msg, details, None, cost)
                found = True
                break
            elif matched is False:
                self.log(f"❌ {i+1}/{total} {sfz}", "red")
            else:
                self.log(f"⚠️ {i+1}/{total} {sfz} 异常", "yellow")

            # 更新进度
            progress = checked / total
            Clock.schedule_once(lambda dt, p=progress: self.app.update_progress(p), 0)

        if not found and not self.stop_flag:
            self.log(f"❌ 全部 {total} 条核验完毕，未找到匹配", "red")
        self.running = False
        Clock.schedule_once(lambda dt: self.app.on_verify_finished(), 0)


# ============================================================
# 主界面
# ============================================================
class MainScreen(BoxLayout):
    """问心无愧 App 主界面"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(6)
        self.padding = dp(10)

        # 引擎
        self.engine = VerifyEngine(self)
        self.verify_thread = None

        # ===== 标题栏 =====
        title_bar = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        title_label = Label(
            text="[b][color=#F85149]问[/color][color=#3FB950]心[/color][color=#D29922]无[/color][color=#58A6FF]愧[/color][/b]  v1.0",
            markup=True,
            font_size=dp(22),
            halign='left',
            valign='middle',
        )
        title_label.bind(size=lambda s, v: setattr(s, 'text_size', v))
        title_bar.add_widget(title_label)

        self.status_dot = Label(
            text="●", font_size=dp(14),
            color=hex_to_rgba(COLORS["green"]),
            size_hint_x=None, width=dp(24),
        )
        title_bar.add_widget(self.status_dot)
        self.status_text = Label(
            text="就绪", font_size=dp(14),
            color=hex_to_rgba(COLORS["text_dim"]),
            halign='right',
        )
        self.status_text.bind(size=lambda s, v: setattr(s, 'text_size', v))
        title_bar.add_widget(self.status_text)
        self.add_widget(title_bar)

        # ===== 输入区 =====
        input_card = BoxLayout(
            orientation='vertical', size_hint_y=None, height=dp(200),
            spacing=dp(8), padding=dp(10),
        )
        input_card.canvas.before.clear()
        with input_card.canvas.before:
            from kivy.graphics import Color as KvColor, RoundedRectangle
            KvColor(*hex_to_rgba(COLORS["panel"]))
            self._input_bg = RoundedRectangle(
                pos=input_card.pos, size=input_card.size, radius=[dp(8)]
            )
            input_card.bind(pos=lambda s,v: setattr(self._input_bg, 'pos', v))
            input_card.bind(size=lambda s,v: setattr(self._input_bg, 'size', v))

        # 姓名
        name_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        name_label = Label(
            text="姓名", size_hint_x=None, width=dp(60),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(14),
            halign='right',
        )
        self.name_input = TextInput(
            hint_text="请输入姓名", multiline=False,
            size_hint_y=None, height=dp(36),
            background_color=hex_to_rgba(COLORS["input_bg"]),
            foreground_color=hex_to_rgba(COLORS["text"]),
            hint_text_color=hex_to_rgba(COLORS["text_dim"]),
            cursor_color=hex_to_rgba(COLORS["accent"]),
            font_size=dp(15),
        )
        name_row.add_widget(name_label)
        name_row.add_widget(self.name_input)
        input_card.add_widget(name_row)

        # 身份证
        sfz_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        sfz_label = Label(
            text="身份证", size_hint_x=None, width=dp(60),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(14),
            halign='right',
        )
        self.sfz_input = TextInput(
            hint_text="18位身份证（x为模糊位）", multiline=False,
            size_hint_y=None, height=dp(36),
            background_color=hex_to_rgba(COLORS["input_bg"]),
            foreground_color=hex_to_rgba(COLORS["text"]),
            hint_text_color=hex_to_rgba(COLORS["text_dim"]),
            cursor_color=hex_to_rgba(COLORS["accent"]),
            font_size=dp(15),
        )
        sfz_row.add_widget(sfz_label)
        sfz_row.add_widget(self.sfz_input)
        input_card.add_widget(sfz_row)

        # 接口选择
        api_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        api_label = Label(
            text="接口", size_hint_x=None, width=dp(60),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(14),
            halign='right',
        )
        self.api_spinner = Spinner(
            text="接口⑥中意财险",
            values=(
                "接口①政务", "接口②51zidan", "接口③i66wan",
                "接口④天津政务", "接口⑤赣服通", "接口⑥中意财险",
                "全部并发", "自选...",
            ),
            size_hint_y=None, height=dp(36),
            background_color=hex_to_rgba(COLORS["input_bg"]),
            color=hex_to_rgba(COLORS["text"]),
            font_size=dp(14),
        )
        api_row.add_widget(api_label)
        api_row.add_widget(self.api_spinner)
        input_card.add_widget(api_row)

        # 线程数
        thr_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        thr_label = Label(
            text="线程", size_hint_x=None, width=dp(60),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(14),
            halign='right',
        )
        self.threads_input = TextInput(
            text="8", multiline=False,
            size_hint_x=None, width=dp(80), height=dp(36),
            background_color=hex_to_rgba(COLORS["input_bg"]),
            foreground_color=hex_to_rgba(COLORS["text"]),
            font_size=dp(15),
        )
        thr_row.add_widget(thr_label)
        thr_row.add_widget(self.threads_input)
        thr_row.add_widget(Label(text="", size_hint_x=1))  # spacer
        input_card.add_widget(thr_row)

        self.add_widget(input_card)

        # ===== 按钮区 =====
        btn_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(10))
        self.btn_verify = Button(
            text="🔍 开始核验",
            background_color=hex_to_rgba(COLORS["accent"]),
            color=(1,1,1,1), font_size=dp(16), bold=True,
        )
        self.btn_verify.bind(on_press=self._on_verify_press)
        btn_row.add_widget(self.btn_verify)

        self.btn_stop = Button(
            text="⏹ 停止",
            background_color=hex_to_rgba(COLORS["warn"]),
            color=(1,1,1,1), font_size=dp(16), bold=True,
            disabled=True,
        )
        self.btn_stop.bind(on_press=self._on_stop_press)
        btn_row.add_widget(self.btn_stop)

        self.btn_clear = Button(
            text="🗑 清屏",
            background_color=hex_to_rgba(COLORS["panel"]),
            color=hex_to_rgba(COLORS["text"]), font_size=dp(14),
        )
        self.btn_clear.bind(on_press=self._on_clear_press)
        btn_row.add_widget(self.btn_clear)

        self.btn_copy = Button(
            text="📋 复制结果",
            background_color=hex_to_rgba(COLORS["panel"]),
            color=hex_to_rgba(COLORS["text"]), font_size=dp(14),
        )
        self.btn_copy.bind(on_press=self._on_copy_press)
        btn_row.add_widget(self.btn_copy)

        self.add_widget(btn_row)

        # ===== 进度条 =====
        self.progress = ProgressBar(
            max=1.0, value=0.0, size_hint_y=None, height=dp(6),
        )
        self.add_widget(self.progress)

        # ===== 日志区 =====
        log_label = Label(
            text="📋 运行日志", size_hint_y=None, height=dp(24),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(12),
            halign='left',
        )
        log_label.bind(size=lambda s, v: setattr(s, 'text_size', v))
        self.add_widget(log_label)

        self.log_view = ScrollView(size_hint_y=1, do_scroll_x=False)
        self.log_layout = GridLayout(cols=1, size_hint_y=None, spacing=dp(2))
        self.log_layout.bind(minimum_height=self.log_layout.setter('height'))
        self.log_view.add_widget(self.log_layout)
        self.add_widget(self.log_view)

        # 底部状态
        self.footer = Label(
            text=f"代理池: {len(_PROXY_LIST)}条 | 核心: {CORE_VERSION}",
            size_hint_y=None, height=dp(20),
            color=hex_to_rgba(COLORS["text_dim"]), font_size=dp(10),
            halign='center',
        )
        self.add_widget(self.footer)

        # 初始日志
        LOG.add(f"问心无愧 手机版 v1.0 启动", "cyan")
        LOG.add(f"代理池: {len(_PROXY_LIST)} 条可用", "text_dim")
        LOG.add(f"接口⑥已就绪（首次核验前自动预热）", "green")
        LOG.add(f"提示: 输入姓名+身份证 → 选择接口 → 点开始核验", "text_dim")
        self._render_log()

    # ===== 事件处理 =====
    def _on_verify_press(self, btn):
        name = self.name_input.text.strip()
        sfz = self.sfz_input.text.strip()
        api = self.api_spinner.text

        if not name:
            self._popup("提示", "请输入姓名")
            return
        if not sfz or len(sfz) != 18:
            self._popup("提示", "身份证必须是18位")
            return

        # 禁用按钮
        self.btn_verify.disabled = True
        self.btn_stop.disabled = False
        self.status_dot.color = hex_to_rgba(COLORS["yellow"])
        self.status_text.text = "核验中..."
        self.progress.value = 0.0

        # 启动后台线程
        self.verify_thread = threading.Thread(
            target=self.engine.single_verify,
            args=(name, sfz, api),
            daemon=True,
        )
        self.verify_thread.start()

    def _on_stop_press(self, btn):
        self.engine.stop_flag = True
        self.log("⏹️ 正在停止...", "yellow")

    def _on_clear_press(self, btn):
        LOG.clear()
        self._render_log()

    def _on_copy_press(self, btn):
        """复制最近一次结果到剪贴板"""
        lines = LOG.get_all()
        if not lines:
            self._popup("提示", "暂无内容可复制")
            return
        text = "\n".join(l[0] for l in lines)
        try:
            from kivy.core.clipboard import Clipboard
            Clipboard.copy(text)
            self._popup("成功", "日志已复制到剪贴板")
        except Exception:
            # Android 上用 pyperclip 兜底
            try:
                import pyperclip
                pyperclip.copy(text)
                self._popup("成功", "日志已复制")
            except Exception as e:
                self._popup("失败", f"复制失败: {e}")

    def _popup(self, title, msg):
        popup = Popup(
            title=title, content=Label(text=msg, color=hex_to_rgba(COLORS["text"])),
            size_hint=(0.8, 0.3),
            background_color=hex_to_rgba(COLORS["panel"]),
        )
        popup.open()

    # ===== UI 更新（主线程调用） =====
    def refresh_log(self):
        self._render_log()

    def update_progress(self, value):
        self.progress.value = max(0.0, min(1.0, value))

    def on_verify_finished(self):
        self.btn_verify.disabled = False
        self.btn_stop.disabled = True
        self.status_dot.color = hex_to_rgba(COLORS["green"])
        self.status_text.text = "就绪"
        self._render_log()

    def _render_log(self):
        """把 LogBuffer 渲染到 ScrollView"""
        lines = LOG.get_all()
        self.log_layout.clear_widgets()
        for text, color_key in lines:
            c = hex_to_rgba(COLORS.get(color_key, "text"))
            # 简单关键词高亮
            if "✅" in text or "匹配" in text or "命中" in text:
                c = hex_to_rgba(COLORS["green"])
            elif "❌" in text or "不匹配" in text:
                c = hex_to_rgba(COLORS["red"])
            elif "⚠️" in text or "异常" in text or "失败" in text:
                c = hex_to_rgba(COLORS["yellow"])
            elif "🔥" in text or "预热" in text:
                c = hex_to_rgba(COLORS["cyan"])

            lbl = Label(
                text=text,
                color=c,
                font_size=dp(11),
                halign='left', valign='top',
                size_hint_y=None,
                height=dp(16),
                text_size=(self.log_view.width - dp(20), None),
            )
            lbl.bind(size=lambda s, v: setattr(s, 'text_size', (s.width, None)))
            self.log_layout.add_widget(lbl)

        # 自动滚到底
        Clock.schedule_once(lambda dt: setattr(self.log_view, 'scroll_y', 0), 0.05)


# ============================================================
# App 入口
# ============================================================
class WenXinApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "问心无愧"
        self.icon = None  # 可放 assets/icon.png

    def build(self):
        # 设置窗口背景
        from kivy.core.window import Window
        Window.clearcolor = hex_to_rgba(COLORS["bg"])
        # 尝试 Android 全屏
        try:
            Window.fullscreen = 'auto'
        except Exception:
            pass
        return MainScreen()

    def on_stop(self):
        LOG.add("应用退出", "text_dim")
        return True


# ============================================================
# 入口
# ============================================================
if __name__ == "__main__":
    WenXinApp().run()
