[app]
title = 问心无愧
package.name = wenxinwukui
package.domain = com.wenxin
source.dir = src
source.include_exts = py,png,jpg,kv,atlas,json,txt
source.exclude_exts = spec
main.filename = main.py
version = 1.0
requirements = python3,kivy,pyjnius,openssl,urllib3,pycryptodome
android.permissions = INTERNET,ACCESS_NETWORK_STATE,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.api = 33
android.ndk = 25b
android.strings = 问心无愧=问心无愧
android.entry_class = org.kivy.android.PythonActivity
android.debug = True
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
build_dir = .buildozer
warn_on_root = True
